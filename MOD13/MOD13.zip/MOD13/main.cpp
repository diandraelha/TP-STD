#include "Graph..h"

int main()
{
    adrNode G;
    //createGraph_1301213072(G);

    adrNode P = newNode_1301213072('A');
    addNode_1301213072(G,P);
    P = newNode_1301213072('C');
    addNode_1301213072(G, P);
    P = newNode_1301213072('D');
    addNode_1301213072(G, P);
    P = newNode_1301213072('B');
    addNode_1301213072(G, P);

    addEdge_1301213072(G, 'A', 'D');
    addEdge_1301213072(G, 'A', 'C');
    addEdge_1301213072(G, 'A', 'B');

    addEdge_1301213072(G, 'C', 'A');

    addEdge_1301213072(G, 'D', 'A');
    addEdge_1301213072(G, 'D', 'B');

    addEdge_1301213072(G, 'B', 'A');
    addEdge_1301213072(G, 'B', 'D');

    printGraph_1301213072(G);

    cout << isConnected_1301213072(G, 'D', 'A');

    return 0;
}
