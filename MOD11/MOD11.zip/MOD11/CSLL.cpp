#include "CSLL.h"

void createPlaylist_1301213072(playlistLagu &Q)
{
    head(Q) = NULL;
    tail(Q) = NULL;
}

void createElement_1301213072(infotype laguBaru, adr &pLagu)
{
    pLagu = new element;
    info(pLagu) = laguBaru;
    next(pLagu) = NULL;
}

void enqueue_1301213072(playlistLagu &Q, adr pLagu)
{

    if (head(Q) == NULL)
    {
        head(Q) = pLagu;
        tail(Q) = pLagu;
    }
    else
    {
        next(pLagu) = head(Q);
        next(tail(Q)) = pLagu;
    }
}

void dequeue_1301213072(playlistLagu &Q, adr &pLagu)
{
    if (head(Q) != NULL)
    {
        pLagu = head(Q);
        head(Q) = next(pLagu);
        next(pLagu) = NULL;
    }
    else
    {
        cout << "List Kosong" << endl;
    }
}

void showSemuaLagu_1301213072(playlistLagu Q)
{
    adr P = head(Q);

    if(head(Q) != NULL)
    {
        while(P != NULL)
        {
            cout << "Artis : " << info(P).Artis << endl;
            cout << "Judul : " << info(P).Judul << endl << endl;
            P = next(P);
        }
    }else{
        cout << "List Kosong" << endl;
    }


}
