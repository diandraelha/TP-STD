#include "atk.h"
int main()
{
   int K, pilihan = 0, x;
    char chara;
    atk data;
    List D;

    createList_1301213072(D);
    pilihan = selectMenu_1301213072();

    while (pilihan != 0){
        switch(pilihan){
        case 1:
            cout << "Jumlah data yang akan ditambahkan : ";
            cin >> x;

            for (int i = 1; i <= x; i++){
                cout << "Masukkan data faktur : ";
                cin >> atk.data_faktur;
                cout << "Nama Barang : ";
                cin >> atk.nama;
                cout << "Jumlah Barang : ";
                cin >> atk.jumlah;
                cout << "Total Harga : ";
                cin >> atk.harga
                data = atk;
                adr P = newElement_1301213072(atk);
                insertFirst_1301213072(D, P);
            }
            break;

        case 2:
            show_1301213072(D);
            break;

        case 3:
            cout << tampil_data(D) <<  << endl;
            break;
        }
     pilihan = selectMenu_1301213072();
    }

    cout << "BYE BYE" << endl;
    return 0;
}
